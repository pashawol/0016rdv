module FoundationEmails
  VERSION = "2.2.1.0"
end
