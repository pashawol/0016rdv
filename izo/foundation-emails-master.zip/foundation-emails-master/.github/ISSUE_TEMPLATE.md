<!-- Please only file bugs with Foundation on GitHub. If you've got a more general question about how to use Foundation, we can help you on the Foundation Forum: http://foundation.zurb.com/forum -->

**How can we reproduce this bug?**

Write out the HTML (or Inky code) that causes the issue.

**What did you expect to happen?**

**What happened instead?**

**What email clients does this happen in?**
